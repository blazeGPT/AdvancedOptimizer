package com.optimizer.advanced;

import com.optimizer.advanced.config.OptimizerConfig;
import com.optimizer.advanced.gui.OptimizerScreen;
import com.optimizer.advanced.keybind.ModKeybinds;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class AdvancedOptimizerClient implements ClientModInitializer {

    public static final String MOD_ID = "advancedoptimizer";
    public static OptimizerConfig CONFIG;

    @Override
    public void onInitializeClient() {
        CONFIG = OptimizerConfig.load();
        ModKeybinds.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (ModKeybinds.OPEN_MENU.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new OptimizerScreen(null));
                }
            }
        });

        System.out.println("[Advanced Optimizer] Cargado para Minecraft 26.3");
    }
}

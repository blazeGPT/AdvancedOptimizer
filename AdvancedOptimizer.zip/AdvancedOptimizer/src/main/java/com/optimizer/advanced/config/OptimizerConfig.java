package com.optimizer.advanced.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class OptimizerConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("advancedoptimizer.json");

    public enum Preset {
        LOW, BALANCED, ULTRA
    }

    public Preset currentPreset = Preset.BALANCED;

    public boolean entityFrustumCulling = true;
    public boolean reduceParticles = true;
    public boolean disableDistantEntities = true;
    public boolean reduceBlockAnimations = true;
    public boolean disableWaterLavaAnimations = false;
    public boolean optimizeLightUpdates = true;
    public boolean cancelUnnecessaryTicks = true;
    public double entityRenderDistance = 64.0;

    public static OptimizerConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                String json = Files.readString(CONFIG_PATH);
                OptimizerConfig config = GSON.fromJson(json, OptimizerConfig.class);
                if (config != null) return config;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        OptimizerConfig config = new OptimizerConfig();
        config.save();
        return config;
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(this));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void applyPreset(Preset preset) {
        this.currentPreset = preset;
        switch (preset) {
            case LOW -> {
                entityFrustumCulling = true;
                reduceParticles = true;
                disableDistantEntities = true;
                reduceBlockAnimations = true;
                disableWaterLavaAnimations = true;
                optimizeLightUpdates = true;
                cancelUnnecessaryTicks = true;
                entityRenderDistance = 48.0;
            }
            case BALANCED -> {
                entityFrustumCulling = true;
                reduceParticles = true;
                disableDistantEntities = true;
                reduceBlockAnimations = true;
                disableWaterLavaAnimations = false;
                optimizeLightUpdates = true;
                cancelUnnecessaryTicks = true;
                entityRenderDistance = 64.0;
            }
            case ULTRA -> {
                entityFrustumCulling = true;
                reduceParticles = true;
                disableDistantEntities = true;
                reduceBlockAnimations = true;
                disableWaterLavaAnimations = true;
                optimizeLightUpdates = true;
                cancelUnnecessaryTicks = true;
                entityRenderDistance = 32.0;
            }
        }
        save();
    }
}

package com.optimizer.advanced.gui;

import com.optimizer.advanced.AdvancedOptimizerClient;
import com.optimizer.advanced.config.OptimizerConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.text.Text;

public class OptimizerScreen extends Screen {

    private final Screen parent;
    private final OptimizerConfig config;

    public OptimizerScreen(Screen parent) {
        super(Text.literal("Advanced Optimizer"));
        this.parent = parent;
        this.config = AdvancedOptimizerClient.CONFIG;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int y = 40;

        this.addDrawableChild(CyclingButtonWidget.builder((OptimizerConfig.Preset p) -> Text.literal(p.name()))
                .values(OptimizerConfig.Preset.values())
                .initially(config.currentPreset)
                .build(centerX - 100, y, 200, 20, Text.literal("Preset"), (button, preset) -> {
                    config.applyPreset(preset);
                }));

        y += 30;

        addToggle(centerX, y, "Entity Frustum Culling", config.entityFrustumCulling,
                v -> config.entityFrustumCulling = v);
        y += 24;
        addToggle(centerX, y, "Reducir Particulas", config.reduceParticles,
                v -> config.reduceParticles = v);
        y += 24;
        addToggle(centerX, y, "Entidades Distantes", config.disableDistantEntities,
                v -> config.disableDistantEntities = v);
        y += 24;
        addToggle(centerX, y, "Animaciones de Bloques", config.reduceBlockAnimations,
                v -> config.reduceBlockAnimations = v);
        y += 24;
        addToggle(centerX, y, "Animaciones Agua/Lava", config.disableWaterLavaAnimations,
                v -> config.disableWaterLavaAnimations = v);
        y += 24;
        addToggle(centerX, y, "Optimizar Luces", config.optimizeLightUpdates,
                v -> config.optimizeLightUpdates = v);
        y += 24;
        addToggle(centerX, y, "Cancelar Ticks Innecesarios", config.cancelUnnecessaryTicks,
                v -> config.cancelUnnecessaryTicks = v);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Guardar y Cerrar"), button -> {
            config.save();
            this.client.setScreen(parent);
        }).dimensions(centerX - 100, this.height - 40, 200, 20).build());
    }

    private void addToggle(int centerX, int y, String name, boolean current, java.util.function.Consumer<Boolean> setter) {
        final boolean[] state = {current};
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal(name + ": " + (state[0] ? "§aON" : "§cOFF")),
                button -> {
                    state[0] = !state[0];
                    setter.accept(state[0]);
                    button.setMessage(Text.literal(name + ": " + (state[0] ? "§aON" : "§cOFF")));
                }
        ).dimensions(centerX - 100, y, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Fondo semi-transparente exacto al 50%
        context.fill(0, 0, this.width, this.height, 0x80000000);

        // Fuente nativa de Minecraft
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 15, 0xFFFFFF);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

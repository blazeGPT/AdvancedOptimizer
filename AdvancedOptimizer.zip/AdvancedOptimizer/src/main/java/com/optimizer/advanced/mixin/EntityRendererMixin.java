package com.optimizer.advanced.mixin;

import com.optimizer.advanced.AdvancedOptimizerClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public class EntityRendererMixin<T extends Entity> {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void advancedOptimizer$frustumCulling(T entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (AdvancedOptimizerClient.CONFIG == null || !AdvancedOptimizerClient.CONFIG.entityFrustumCulling) {
            return;
        }

        double maxDist = AdvancedOptimizerClient.CONFIG.entityRenderDistance;
        if (entity.squaredDistanceTo(x, y, z) > maxDist * maxDist) {
            cir.setReturnValue(false);
        }
    }
}

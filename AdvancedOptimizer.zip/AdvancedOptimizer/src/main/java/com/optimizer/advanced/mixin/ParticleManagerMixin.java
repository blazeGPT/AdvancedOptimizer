package com.optimizer.advanced.mixin;

import com.optimizer.advanced.AdvancedOptimizerClient;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleManager.class)
public class ParticleManagerMixin {

    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;", at = @At("HEAD"), cancellable = true)
    private void advancedOptimizer$reduceParticles(ParticleEffect parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfoReturnable<?> cir) {
        if (AdvancedOptimizerClient.CONFIG == null || !AdvancedOptimizerClient.CONFIG.reduceParticles) {
            return;
        }

        // Cancela algunas partículas comunes cuando el preset es agresivo
        if (AdvancedOptimizerClient.CONFIG.currentPreset == com.optimizer.advanced.config.OptimizerConfig.Preset.ULTRA) {
            if (parameters.getType() == ParticleTypes.SMOKE ||
                parameters.getType() == ParticleTypes.CLOUD ||
                parameters.getType() == ParticleTypes.ASH ||
                parameters.getType() == ParticleTypes.WHITE_ASH) {
                cir.setReturnValue(null);
            }
        }
    }
}
